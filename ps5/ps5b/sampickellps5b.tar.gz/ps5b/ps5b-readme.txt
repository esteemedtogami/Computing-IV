/**********************************************************************
 *  readme.txt template                                                   
 *  Plucking a Guitar String
 **********************************************************************/

Name: Sam Pickell
CS Login: spickell


Hours to complete assignment (optional): 5 hours and 53 minutes


/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/

 I successfully completed the whole assignment. When you press a proper
key a sound plays and if you press the wrong key no sounds play.


/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  As a pair, or individually?
 *  If you completed the AutoGuitar, what does it play?
 **********************************************************************/

 I did not attempt the extra credit.


/**********************************************************************
 *  Does your GuitarString implementation pass the unit tests?
 *  Indicate yes or no, and explain how you know that it does or does not.
 **********************************************************************/

 Yes, my programs pass the unit tests. I implemented the boost code given
on the website before I started working on my main file.


/**********************************************************************
 *  List whatever help (if any) you received from lab TAs,
 *  classmates, or anyone else.
 **********************************************************************/

 I had a bit of help with pointers from Mike Moran, otherwise I did the
program myself. 


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/

 No serious problems occurred.


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
