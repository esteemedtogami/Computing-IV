/**********************************************************************
 *  readme.txt template                                                   
 *  Markov Model
 **********************************************************************/

Name: Sam Pickell


Hours to complete assignment (optional): 4 hours and 30 minutes


/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
Yes, I completed the whole assignment. I know it is working because it
successfully compiles and runs and passes the Boost tests provided on
the website as well as generates text as per the Princeton assignment
with input17.txt.

/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  
 **********************************************************************/
I did not attempt the extra credit.

/**********************************************************************
 *  Does your implementation pass the unit tests?
 *  Indicate yes or no, and explain how you know that it does or does not.
 **********************************************************************/
Yes, it does. I ran the Boost test and finished with no errors.

/**********************************************************************
 *  List whatever help (if any) you received from lab TAs,
 *  classmates, or anyone else.
 **********************************************************************/

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
No serious problems encountered.

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
